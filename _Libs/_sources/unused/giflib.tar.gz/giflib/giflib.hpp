/******************************************************************************

gif_lib.h - service library for decoding and encoding GIF images

*****************************************************************************/

#ifndef GIFLIB_HPP
#define GIFLIB_HPP

extern "C"
{
    #include "gif_lib.h"
}

#endif // GIFLIB_HPP
