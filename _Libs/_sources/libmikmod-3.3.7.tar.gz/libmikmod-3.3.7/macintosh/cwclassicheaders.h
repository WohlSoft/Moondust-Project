
	/* platform */
#define TARGET_API_MAC_OS8    1
#define TARGET_API_MAC_CARBON 0

#define MSL_USE_PRECOMPILED_HEADERS	1

#include "cwmikmodheaders.h"
