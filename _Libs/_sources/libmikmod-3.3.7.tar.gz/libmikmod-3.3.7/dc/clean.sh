#! /bin/sh

kos_dir=/opt/toolchains/dc/kos
. ${kos_dir}/environ.sh

make -f Makefile.dc clean
