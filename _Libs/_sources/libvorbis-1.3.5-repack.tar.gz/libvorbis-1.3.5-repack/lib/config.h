/* Define to 1 if you have <alloca.h> and it should be used (not on Ultrix).
   */
#ifndef _WIN32
#define HAVE_ALLOCA_H 1
#endif

