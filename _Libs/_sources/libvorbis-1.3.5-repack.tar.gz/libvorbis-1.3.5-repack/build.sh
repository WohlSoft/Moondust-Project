#!/bin/bash
./build-vorbis.sh $1
./build-vorbisfile.sh $1
./build-vorbisenc.sh $1

