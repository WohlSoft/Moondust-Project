}

#elif !defined(GLEW_OSMESA) /* _UNIX */

static void glxewInfo ()
{
