}

/* ------------------------------------------------------------------------ */

#if defined(_WIN32) && !defined(GLEW_OSMESA)

static void wglewInfo ()
{
