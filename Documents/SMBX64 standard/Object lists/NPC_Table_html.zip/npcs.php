<?php
require_once("../../../../../sys/db.php");
?>
<!DOCTYPE html>
<html><head><title>testdoc</title>
<style type="text/css">
   
    h2, h3 {
      width: 100%;
      text-align: center;
      margin: 1.5em 0 .5em 0;
    }
    p {
      width: 50%;
      margin: 10px auto;
    }
    
    a {
      color: black;
      text-decoration: underline;
    }
    a:hover {
      text-decoration: none;
      background-color: #D5ECFF;
    }
    td {
      border-bottom: 1px solid #ccc;
      padding: 5px;
      text-align: left; /* IE */
    }
    td + td {
      border-left: 1px solid #ccc;
    }
    th {
      padding: 0 5px;
      text-align: left; /* IE */
    }
    .header-background {
      border-bottom: 1px solid black;
    }
    
    /* above this is decorative, not part of the test */
    
    .fixed-table-container {
      width: 4000px;
      height: 700px;
      border: 1px solid black;
      margin: 10px auto;
      background-color: white;
      /* above is decorative or flexible */
      position: relative; /* could be absolute or relative */
      padding-top: 50px; /* height of header */
    }

    .fixed-table-container-inner {
      overflow-x: hidden;
      overflow-y: auto;
      height: 100%;
    }
     
    .header-background {
      background-color: #D5ECFF;
      height: 50px; /* height of header */
      position: absolute;
      top: 0;
      right: 0;
      left: 0;
    }
    
    table {
      background-color: white;
      width: 100%;
      overflow-x: hidden;
      overflow-y: auto;
    }

    .th-inner {
      //white-space: nowrap;
      position: absolute;
      top: 0;
      line-height: 50px; /* height of header */
      text-align: left;
      border-left: 1px solid black;
      padding-left: 5px;
      margin-left: -5px;
    }
    .first .th-inner {
        border-left: none;
        padding-left: 6px;
      }
		
		/* extra-wrap */
		
		.extrawrap th {
			text-align: center;
		}
		
		.extra-wrap {
			width: 100%;
		}
		
		/* Zupa styles for centered headers */
		
		.zupa div.zupa1 {
			margin: 0 auto !important;
			width: 0 !important;
		}
		
		.zupa div.th-inner {
			width: 100%;
			margin-left: -50%;
			text-align: center;
			border: none;
		}

    /* for hidden header hack to calculate widths of dynamic content */
    
    .hidden-head {
      min-width: 530px; /* enough width to show all header text, or bad things happen */
    }
    
    .hidden-header .th-inner {
      position: static;
      overflow-y: hidden;
      height: 0;
      white-space: nowrap;
      padding-right: 5px;
    }
    
</style></head>

<body>
<h2>Hardcoded values table of SMBX NPC's</h2>
<?php
$query = mysql_query("SELECT * FROM _smbx64_npcs;");
?>
<div>

    <div class="fixed-table-container">
      <div class="header-background"> </div>
      <div class="fixed-table-container-inner">

<table style="width: 100%; border: 1px solid #000000;">
<thead>
<tr style="background-color: #FFFFFF; border: 1px solid #000000;">
<th><div class="th-inner">NPC</div></th>
<th><div class="th-inner">ID</div></th>
<th><div class="th-inner">GFX Offset X</div></th>
<th><div class="th-inner">GFX Offset Y</div></th>
<th><div class="th-inner">Width</div></th>
<th><div class="th-inner">Height</div></th>
<th><div class="th-inner">GFX Width</div></th>
<th><div class="th-inner">GFX Height</div></th>
<th><div class="th-inner">Is shell</div></th>
<th><div class="th-inner">Npc Block</div></th>
<th><div class="th-inner">Npc Block Top</div></th>
<th><div class="th-inner">Is Interactable NPC</div></th>
<th><div class="th-inner">Is Coin</div></th>
<th><div class="th-inner">Is Vine</div></th>
<th><div class="th-inner">Is Collectable Goal</div></th>
<th><div class="th-inner">Is Flying koopa</div></th>
<th><div class="th-inner">Is Fish</div></th>
<th><div class="th-inner">Jumphurt</div></th>
<th><div class="th-inner">No Block Collision</div></th>
<th><div class="th-inner">Score</div></th>
<th><div class="th-inner">Player Block Top</div></th>
<th><div class="th-inner">Grab Top</div></th>
<th><div class="th-inner">Cliff Turn</div></th>
<th><div class="th-inner">No hurt</div></th>
<th><div class="th-inner">Player Block</div></th>
<th><div class="th-inner">Unknown [0xB295D6]</div></th>
<th><div class="th-inner">Grab Side</div></th>
<th><div class="th-inner">Is Shoe NPC</div></th>
<th><div class="th-inner">Is Yoshi NPC</div></th>
<th><div class="th-inner">Unknown [0xB29F3E]</div></th>
<th><div class="th-inner">No Yoshi</div></th>
<th><div class="th-inner">Foreground</div></th>
<th><div class="th-inner">Is Bot</div></th>
<th><div class="th-inner">Unknown [0xB2A8A6]</div></th>
<th><div class="th-inner">Is Vegetable NPC</div></th>
<th><div class="th-inner">Speed</div></th>
<th><div class="th-inner">No Fireball</div></th>
<th><div class="th-inner">No Iceball</div></th>
<th><div class="th-inner">No Gravity</div></th>
</tr>
          </thead>
          <tbody>
<tr style="color: #FFFFFF;">
<td>NPC</td>
<td>ID</td>
<td>GFX Offset X</td>
<td>GFX Offset Y</td>
<td>Width</td>
<td>Height</td>
<td>GFX Width</td>
<td>GFX Height</td>
<td>Is shell</td>
<td>Npc Block</td>
<td>Npc Block Top</td>
<td>Is Interactable NPC</td>
<td>Is Coin</td>
<td>Is Vine</td>
<td>Is Collectable Goal</td>
<td>Is Flying koopa</td>
<td>Is Fish</td>
<td>Jumphurt</td>
<td>No Block Collision</td>
<td>Score</td>
<td>Player Block Top</td>
<td>Grab Top</td>
<td>Cliff Turn</td>
<td>No hurt</td>
<td>Player Block</td>
<td>Unknown [0xB295D6]</td>
<td>Grab Side</td>
<td>Is Shoe NPC</td>
<td>Is Yoshi NPC</td>
<td>Unknown [0xB29F3E]</td>
<td>No Yoshi</td>
<td>Foreground</td>
<td>Is Bot</td>
<td>Unknown [0xB2A8A6]</td>
<td>Is Vegetable NPC</td>
<td>Speed</td>
<td>No Fireball</td>
<td>No Iceball</td>
<td>No Gravity</td>
</tr>
	<?php  while(($npc = mysql_fetch_array($query))!=NULL )
	{?>
    <tr><td class="headcol" style="width: 64px;"><img src="img/npc-<?=$npc['id']?>.png" alt="<?=$npc['id']?>"/></td>
	<?php
	for($i=0;$i<38;$i++)
	{
	echo "<td>".$npc[$i]."</td>";
	}
	?>
	</tr>
	<?php  } ?>
         </tbody>
</table>

      </div>
    </div>

</div>

</body></html>