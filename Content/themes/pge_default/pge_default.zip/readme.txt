This is example of full theme pack. It have all available to replace images.
